//
//  SearchView.swift
//  Krates
//
//  Created by Eli Lopez on 10/4/23.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        Text("Search View")
    }
}

#Preview {
    SearchView()
}
